
const Creditsl = () => {
    return (  
        <div>
            <h1>Credit sales Page</h1>
        </div>        
    );
}
 
export default Creditsl;