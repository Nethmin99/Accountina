
const Cashsl = () => {
    return (  
        <div>
            <h1>Cash sales Page</h1>
        </div>        
    );
}
 
export default Cashsl;