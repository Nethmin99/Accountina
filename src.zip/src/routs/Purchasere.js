const Purchasere = () => {
    return (  
        <div>
            <h1>Purchase return Page</h1>
        </div>
    );
}
 
export default Purchasere;