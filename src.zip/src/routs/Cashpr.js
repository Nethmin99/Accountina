
const Cashpr = () => {
    return (  
        <div>
            <h1>Cash purchase page</h1>
        </div>        
    );
}
 
export default Cashpr;