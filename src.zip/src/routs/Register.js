import FormReg from "../Component/FormReg"
import './route.css'

const Register = () => {
    return ( 
            <div id='register'>
                <FormReg/>
            </div>
     );
}
 
export default Register;