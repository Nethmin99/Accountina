
const Salesre = () => {
    return (  
        <div>
            <h1>Sales return Page</h1>
        </div>        
    );
}
 
export default Salesre;