const Creditpr = () => {
    return (  
        <h1>Credit Purchase Page</h1>
    );
}
<h1>Credit Purchase Page</h1> 

export default Creditpr;